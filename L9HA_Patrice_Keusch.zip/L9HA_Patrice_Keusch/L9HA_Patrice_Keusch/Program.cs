﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9HA_Patrice_Keusch
{
    class Program
    {
        static void Main(string[] args)
        {

            using (var db = new SchoolEntities())
            {
                Console.Write("Enter new ad:");
                var name = Console.ReadLine();
                new Person
            }
        }
    }
}
