﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L4U1
{
    class Person
    {
        public String Name { get; set; }
        public String Vorname { get; set; }
    }
}
